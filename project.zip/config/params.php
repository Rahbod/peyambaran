<?php

return [
    'adminEmail' => 'admin@example.com',
    'dbDateTimeFormat' => 'Y-m-d H:i:s',
    'dbDateFormat' => 'Y-m-d',
    'dbTimeFormat' => 'H:i:s',
];
